son = input("sonni kiriting: ")
for son in range(10, 100):
    for i in range(2, son):
        if son % i== 0:
            break
    else:
        print(son, end=" ")