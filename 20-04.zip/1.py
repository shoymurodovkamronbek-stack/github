n = int(input("n ni kiriting: "))
yigindi= 0
for i in range(1, n + 1):
    yigindi+= i

print("yigindi: ", yigindi)    
