n = int(input("n ni kiriting: "))

for i in range(n, 0, -1):
    print(i, end=" ")