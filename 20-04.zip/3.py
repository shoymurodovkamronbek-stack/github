son = input("sonni kiriting: ")

for i in son:
    print(i, end=" ")